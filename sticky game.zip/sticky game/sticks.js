let sticks = 21;
let playersTurn = true;
let gameOver = false;
let difficulty = "medium";
let goesFirst = "player";
let animating = false;

let roastMessages = [
    "My grandma plays better than you, and she's a lamp.",
    "Congratulations, you found the one way to lose at a 2-option game.",
    "The sticks feel sorry for you. I don't.",
    "Even on Easy mode? Really?",
    "That was so bad the computer felt bad for winning.",
    "You had ONE job. Don't take the last stick. You took it anyway.",
    "Are you sure you don't want to switch to Tic-Tac-Toe?",
    "The sticks have filed a restraining order against your strategy.",
    "Bold of you to lose this hard. Most people try harder by accident.",
    "I've seen better decision-making from a coinflip.",
    "Somewhere, a rock just outsmarted you.",
    "The AI didn't even have to try. It's embarrassed for you.",
    "You didn't just lose. You lost with *style*.",
    "Stick Game? More like Slick Game because you just slid right into defeat.",
    "Plot twist: the sticks were the real winners here.",
    "Have you considered a career in losing? You're a natural.",
    "That move was so bad it has its own Wikipedia page.",
    "Even a goldfish would've seen that coming.",
    "The computer just wrote in its diary: 'Easiest win ever.'",
    "That wasn't a strategy. That was a cry for help."
];

/* ── Loading Screen ── */
window.addEventListener("DOMContentLoaded", function () {
    initParticles();

    let fill = document.getElementById("loaderFill");
    let text = document.getElementById("loaderText");
    let msgs = [
        "Sharpening the sticks...",
        "Warming up the AI...",
        "Almost ready..."
    ];
    let step = 0;

    let iv = setInterval(function () {
        step++;
        let pct = Math.min(step * 25, 100);
        fill.style.width = pct + "%";
        if (step <= msgs.length) text.textContent = msgs[step - 1];
        if (pct >= 100) {
            clearInterval(iv);
            setTimeout(function () {
                document.getElementById("loadingScreen").classList.add("hidden");
                document.getElementById("gameWrapper").classList.add("visible");
            }, 400);
        }
    }, 500);
});

/* ── Particle Canvas ── */
function initParticles() {
    let canvas = document.getElementById("particles");
    let ctx = canvas.getContext("2d");
    let particles = [];
    let count = 60;

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < count; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            r: Math.random() * 2 + 0.5,
            dx: (Math.random() - 0.5) * 0.4,
            dy: (Math.random() - 0.5) * 0.4,
            o: Math.random() * 0.4 + 0.1
        });
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < particles.length; i++) {
            let p = particles[i];
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = "rgba(255,255,255," + p.o + ")";
            ctx.fill();
            p.x += p.dx;
            p.y += p.dy;
            if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
            if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
        }
        requestAnimationFrame(draw);
    }
    draw();
}

/* ── Difficulty Picker ── */
function showDifficulty() {
    if (animating) return;
    let box = document.getElementById("gameBox");
    box.style.opacity = "0";
    box.style.transform = "scale(0.95)";

    setTimeout(function () {
        let html = '<p class="diff-section-title">Choose your challenge</p>';
        html += '<button class="btn diff-btn easy" onclick="showWhoGoesFirst(\'easy\')">Easy</button> ';
        html += '<button class="btn diff-btn medium" onclick="showWhoGoesFirst(\'medium\')">Medium</button> ';
        html += '<button class="btn diff-btn hard" onclick="showWhoGoesFirst(\'hard\')">Hard</button>';
        box.innerHTML = html;
        box.style.opacity = "1";
        box.style.transform = "scale(1)";
    }, 250);
}

/* ── Who Goes First Picker ── */
function showWhoGoesFirst(diff) {
    if (animating) return;
    difficulty = diff;
    let box = document.getElementById("gameBox");
    box.style.opacity = "0";
    box.style.transform = "scale(0.95)";

    setTimeout(function () {
        let html = '<p class="diff-section-title">Who goes first?</p>';
        html += '<button class="btn diff-btn easy" onclick="startGame(\'player\')">You</button> ';
        html += '<button class="btn diff-btn hard" onclick="startGame(\'computer\')">Computer</button>';
        box.innerHTML = html;
        box.style.opacity = "1";
        box.style.transform = "scale(1)";
    }, 250);
}

/* ── Start Game ── */
function startGame(first) {
    if (animating) return;
    goesFirst = first;
    sticks = 21;
    gameOver = false;

    let box = document.getElementById("gameBox");
    let log = document.getElementById("log");
    log.innerHTML = "";

    box.style.opacity = "0";
    box.style.transform = "scale(0.95)";

    setTimeout(function () {
        if (goesFirst === "computer") {
            playersTurn = false;
            render(box);
            logMessage("Game started on " + capitalize(difficulty) + " difficulty!");
            logMessage("21 sticks. Take 1 or 2. Last stick loses!");
            logMessage("Computer goes first!");
            animating = true;
            setTimeout(function () {
                animating = false;
                computerTurn();
            }, 1000);
        } else {
            playersTurn = true;
            render(box);
            logMessage("Game started on " + capitalize(difficulty) + " difficulty!");
            logMessage("21 sticks. Take 1 or 2. Last stick loses!");
            logMessage("You go first!");
        }
        box.style.opacity = "1";
        box.style.transform = "scale(1)";
    }, 250);
}

/* ── Render ── */
function render(box) {
    let sticksHtml = '<div class="sticks-area">';
    for (let i = 0; i < sticks; i++) {
        sticksHtml += '<div class="stick" style="animation-delay:' + (i * 0.02) + 's"></div>';
    }
    sticksHtml += "</div>";

    let html = '<div class="sticks-count">' + sticks + ' sticks remaining</div>';
    html += sticksHtml;
    html += '<div class="diff-label">Difficulty: ' + capitalize(difficulty) + ' | ' + (goesFirst === "player" ? "You" : "Computer") + ' goes first</div>';

    if (gameOver) {
        let isWin = sticks === 0 && !playersTurn;
        let bannerClass = isWin ? "win" : "lose";
        let bannerText = isWin ? "You Win!" : "You Lose!";
        html += '<div class="game-over-banner ' + bannerClass + '">' + bannerText + '</div>';
        html += '<button class="btn btn-glow" onclick="showDifficulty()">Play Again</button>';
    } else if (playersTurn) {
        html += '<div style="margin-top:16px">';
        html += '<button class="btn" onclick="take(1)">Take 1</button> ';
        if (sticks >= 2) {
            html += '<button class="btn" onclick="take(2)">Take 2</button>';
        }
        html += "</div>";
    } else {
        html += '<div class="thinking"><span></span><span></span><span></span></div>';
    }

    box.innerHTML = html;
}

/* ── Animate Stick Removal ── */
function animateRemoval(count, callback) {
    let area = document.querySelector(".sticks-area");
    if (!area) { callback(); return; }

    let allSticks = area.querySelectorAll(".stick");
    let toRemove = [];

    for (let i = 0; i < count && i < allSticks.length; i++) {
        toRemove.push(allSticks[allSticks.length - 1 - i]);
    }

    toRemove.forEach(function (s, idx) {
        setTimeout(function () {
            s.classList.add("removing");
        }, idx * 100);
    });

    setTimeout(callback, toRemove.length * 100 + 400);
}

/* ── Player Take ── */
function take(n) {
    if (gameOver || !playersTurn || animating) return;
    if (n > sticks) return;

    animating = true;
    let sticksBefore = sticks;
    sticks -= n;
    logMessage("You took " + n + " stick" + (n > 1 ? "s" : "") + ". " + sticks + " left.");

    if (sticks === 0) {
        gameOver = true;
        logMessage("You took the last stick — you lose!");
        let box = document.getElementById("gameBox");
        render(box);
        animateRemoval(n, function () {
            showGameOverScreen(false);
            animating = false;
        });
        return;
    }

    animateRemoval(n, function () {
        let box = document.getElementById("gameBox");
        render(box);
        playersTurn = false;
        render(box);
        animating = false;
        setTimeout(computerTurn, 600);
    });
}

/* ── Computer Turn ── */
function computerTurn() {
    if (gameOver || animating) return;

    animating = true;

    let takeAmount;
    if (difficulty === "easy") {
        takeAmount = easyMove(sticks);
    } else if (difficulty === "hard") {
        takeAmount = optimalMove(sticks);
    } else {
        takeAmount = mediumMove(sticks);
    }

    sticks -= takeAmount;
    logMessage("Computer took " + takeAmount + " stick" + (takeAmount > 1 ? "s" : "") + ". " + sticks + " left.");

    if (sticks === 0) {
        gameOver = true;
        logMessage("Computer took the last stick — you win!");
        let box = document.getElementById("gameBox");
        render(box);
        animateRemoval(takeAmount, function () {
            showGameOverScreen(true);
            animating = false;
        });
        return;
    }

    animateRemoval(takeAmount, function () {
        playersTurn = true;
        let box = document.getElementById("gameBox");
        render(box);
        animating = false;
    });
}

/* ── AI Logic ── */
function easyMove(remaining) {
    if (remaining === 1) return 1;
    return Math.random() < 0.5 ? 1 : 2;
}

function mediumMove(remaining) {
    if (remaining === 1) return 1;
    if (remaining === 2) return 1;
    if (Math.random() < 0.4) return optimalMove(remaining);
    return Math.random() < 0.5 ? 1 : 2;
}

function optimalMove(remaining) {
    if (remaining === 1) return 1;
    if (remaining === 2) return 1;
    let mod = remaining % 3;
    if (mod === 2) return 1;
    if (mod === 0) return 2;
    return 1;
}

/* ── Game Over Screen ── */
function showGameOverScreen(isWin) {
    let screen = document.getElementById("gameoverScreen");
    screen.className = "gameover-screen " + (isWin ? "win" : "lose");

    let html = "";
    if (isWin) {
        html += '<div class="win-title">You Win!</div>';
        html += '<div class="win-subtitle">The computer took the last stick. Well played!</div>';
        html += '<button class="btn btn-glow gameover-btn" onclick="closeGameOver()">Play Again</button>';
    } else {
        html += '<div class="lose-title-wrap">';
        html += '<div class="lose-title">You Lose!</div>';
        html += '<div class="lose-glare"></div>';
        html += '</div>';
        html += '<div class="lose-roast">"' + roastMessages[Math.floor(Math.random() * roastMessages.length)] + '"</div>';
        html += '<button class="btn btn-glow gameover-btn" onclick="closeGameOver()">Try Again</button>';
    }

    screen.innerHTML = html;

    requestAnimationFrame(function () {
        screen.classList.add("active");
    });

    if (isWin) {
        spawnConfetti();
    }
}

function closeGameOver() {
    let screen = document.getElementById("gameoverScreen");
    screen.classList.remove("active");
    screen.innerHTML = "";
    showDifficulty();
}

/* ── Confetti ── */
function spawnConfetti() {
    let colors = ["#50c878", "#ff6ec7", "#1e90ff", "#ffd700", "#e040a0", "#ffffff"];
    for (let i = 0; i < 50; i++) {
        let el = document.createElement("div");
        el.className = "confetti";
        el.style.left = Math.random() * 100 + "vw";
        el.style.top = -10 + "px";
        el.style.background = colors[Math.floor(Math.random() * colors.length)];
        el.style.width = (Math.random() * 8 + 5) + "px";
        el.style.height = (Math.random() * 8 + 5) + "px";
        el.style.animationDuration = (Math.random() * 2 + 1.5) + "s";
        el.style.animationDelay = (Math.random() * 0.8) + "s";
        document.body.appendChild(el);
        setTimeout(function () { el.remove(); }, 4000);
    }
}

/* ── Utilities ── */
function logMessage(msg) {
    let log = document.getElementById("log");
    let p = document.createElement("p");
    p.textContent = msg;
    log.appendChild(p);
    log.scrollTop = log.scrollHeight;
}

function capitalize(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
}

function screenFlash(type) {
    let el = document.createElement("div");
    el.className = "screen-flash " + type;
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 700);
}
